<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.


class Widget_ProgressionElementsCrowdFundingList extends Widget_Base {

	
	public function get_name() {
		return 'progression-episode-post-list';
	}

	public function get_title() {
		return esc_html__( 'Crowdfunding Posts', 'progression-elements-multifondo' );
	}

	public function get_icon() {
		return 'eicon-post-list progression-studios-helpmeout-pe';
	}

   public function get_categories() {
		return [ 'progression-studios-helpmeout' ];
	}
	
	
	function Widget_ProgressionElementsCrowdFundingList($widget_instance){
		
	}
	
	protected function _register_controls() {

		
  		$this->start_controls_section(
  			'section_title_global_options',
  			[
  				'label' => esc_html__( 'Crowdfunding Settings', 'progression-elements-multifondo' )
  			]
  		);
		
		$this->add_control(
			'progression_main_post_count',
			[
				'label' => esc_html__( 'Post Count', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '6',
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_image_grid_column_count',
			[
  				'label' => esc_html__( 'Columns', 'progression-elements-multifondo' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,				
				'desktop_default' => '33.330%',
				'tablet_default' => '50%',
				'mobile_default' => '100%',
				'options' => [
					'100%' => esc_html__( '1 Column', 'progression-elements-multifondo' ),
					'50%' => esc_html__( '2 Column', 'progression-elements-multifondo' ),
					'33.330%' => esc_html__( '3 Columns', 'progression-elements-multifondo' ),
					'25%' => esc_html__( '4 Columns', 'progression-elements-multifondo' ),
					'20%' => esc_html__( '5 Columns', 'progression-elements-multifondo' ),
					'16.67%' => esc_html__( '6 Columns', 'progression-elements-multifondo' ),
				],
				'selectors' => [
					'{{WRAPPER}} .progression-masonry-item' => 'width: {{VALUE}};',
				],
				'render_type' => 'template'
			]
		);
		
		
  		$this->add_responsive_control(
  			'progression_elements_image_grid_margin',
  			[
  				'label' => esc_html__( 'Margin', 'progression-elements-multifondo' ),
  				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .progression-masonry-margins' => 'margin-left:-{{SIZE}}px; margin-right:-{{SIZE}}px;',
					'{{WRAPPER}} .progression-masonry-padding-blog' => 'padding: {{SIZE}}px;',
				],
				'render_type' => 'template'
  			]
  		);
		
		
		$this->add_control(
			'boosted_post_list_masonry',
			[
				'label' => esc_html__( 'Masonry Layout', 'progression-elements-progression' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_list_pagination',
			[
				'label' => esc_html__( 'Post Pagination', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'no-pagination',
				'options' => [
					'no-pagination' => esc_html__( 'No Pagination', 'progression-elements-multifondo' ),
					'default' => esc_html__( 'Default Pagination', 'progression-elements-multifondo' ),
					'load-more' => esc_html__( 'Load More Posts', 'progression-elements-multifondo' ),
					'infinite-scroll' => esc_html__( 'Inifinite Scroll', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_main_post_load_more',
			[
				'label' => esc_html__( 'Load More Text', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Load More',
				'condition' => [
					'progression_elements_post_list_pagination' => 'load-more',
				],
			]
		);

		
		$this->end_controls_section();
		
		
  		$this->start_controls_section(
  			'section_title_layout_options',
  			[
  				'label' => esc_html__( 'Post Layout', 'progression-elements-multifondo' )
  			]
  		);

		
		$this->add_control(
			'progression_elements_post_meta_category_place',
			[
				'label' => esc_html__( 'Percent Text Location', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'below',
				'options' => [
					'above' => esc_html__( 'Above Percent', 'progression-elements-multifondo' ),
					'below' => esc_html__( 'Below Percent', 'progression-elements-multifondo' ),
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_show_cat',
			[
				'label' => esc_html__( 'Shop Category', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_showbyline',
			[
				'label' => esc_html__( 'Shop  Byline', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_raised',
			[
				'label' => esc_html__( 'Shop Raised', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_goal',
			[
				'label' => esc_html__( 'Shop Goal', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_percent',
			[
				'label' => esc_html__( 'Shop Percentage', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_percent_text',
			[
				'label' => esc_html__( 'Shop Percentage Text', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_time_remaining',
			[
				'label' => esc_html__( 'Shop Time Remaining', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_main_post_play_more_btn',
			[
				'label' => esc_html__( 'Read More Text', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'View Project',
			]
		);
		
		
		
		

		
		$this->end_controls_section();
		
		
  		$this->start_controls_section(
  			'section_title_secondary_options',
  			[
  				'label' => esc_html__( 'Post Query', 'progression-elements-multifondo' )
  			]
  		);
		
		
		$this->add_control(
			'progression_slider_tags',
			[
				'label' => esc_html__( 'Narrow by Category', 'progression-elements-multifondo' ),
				'description' => esc_html__( 'Choose a category to display projects', 'progression-elements-multifondo' ),
				'label_block' => true,
				'multiple' => true,
				'type' => Controls_Manager::SELECT2,
				'options' => helpmeout_elements_post_type_categories(),
			]
		);
		
		
		
		
		$this->add_control(
			'progression_elements_post_order_sorting',
			[
				'label' => esc_html__( 'Order By', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date' => esc_html__( 'Default - Date', 'progression-elements-multifondo' ),
					'title' => esc_html__( 'Post Title', 'progression-elements-multifondo' ),
					'menu_order' => esc_html__( 'Menu Order', 'progression-elements-multifondo' ),
					'modified' => esc_html__( 'Last Modified', 'progression-elements-multifondo' ),
					'rand' => esc_html__( 'Random', 'progression-elements-multifondo' ),
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_order',
			[
				'label' => esc_html__( 'Order', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC' => esc_html__( 'Ascending', 'progression-elements-multifondo' ),
					'DESC' => esc_html__( 'Descending', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_main_offset_count',
			[
				'label' => esc_html__( 'Offset Count', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '0',
				'description' => esc_html__( 'Use this to skip over posts (Example: 3 would skip the first 3 posts.)', 'progression-elements-multifondo' ),
			]
		);
		
		$this->add_control(
			'progression_elements_post_featured',
			[
				'label' => esc_html__( 'Featured Products', 'progression-elements-multifondo' ),
				'description' => esc_html__( 'Display featured products only', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		
		$this->add_control(
			'progression_elements_slider_sorting_on',
			[
				'label' => esc_html__( 'Filtering Sorting', 'progression-elements-multifondo' ),
				'description' => esc_html__( 'Sort by Filtering Tags', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		
		$this->add_control(
			'progression_elements_category_sorting_text',
			[
				'label' => esc_html__( 'Sorting Text for All Posts', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'All', 'progression-elements-multifondo' ),
			]
		);
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'progression_elements_section_main_styles',
			[
				'label' => esc_html__( 'Main Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'progression_elements_main_bg_color',
			[
				'label' => esc_html__( 'Main Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-shop-index-content' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		
		$this->add_control(
			'progression_elements_image_background_color',
			[
				'label' => esc_html__( 'Main Border Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-shop-index-content' => 'border-color: {{VALUE}}',
				],
			]
		);
		

		
		$this->add_responsive_control(
			'progression_elements_content_padding',
			[
				'label' => esc_html__( 'Content Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .progression-studios-shop-index-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		

		
		$this->end_controls_section();
		
		
		
		
		
		
		$this->start_controls_section(
			'section_styles_title_styles',
			[
				'label' => esc_html__( 'Title Styles', 'progression-elements-viseo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'progression_elements_title_styles_color',
			[
				'label' => esc_html__( 'Title Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .progression-studios-shop-index-content h2.woocommerce-loop-product__title' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_title_styles_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .campaign-listing-page .wpneo-listing-content h4:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .wpcrowd-admin-title h3 a:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} ul.products li.product .progression-studios-shop-index-content a:hover h2.woocommerce-loop-product__title' => 'color: {{VALUE}}',
				'{{WRAPPER}} ul.products li.product .progression-studios-shop-index-content a:hover h2.woocommerce-loop-category__title' => 'color: {{VALUE}}',
					
				],
			]
		);
		
		

		
		$this->add_responsive_control(
			'progression_elements_title_margin',
			[
				'label' => esc_html__( 'Title Margin', 'progression-elements-viseo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .progression-studios-shop-index-content h2.woocommerce-loop-product__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_title_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-viseo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.products li.product .progression-studios-shop-index-content h2.woocommerce-loop-product__title',
			]
		);
		
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_styles_category_styles',
			[
				'label' => esc_html__( 'Byline', 'progression-elements-viseo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'progression_elements_category_styles_color',
			[
				'label' => esc_html__( 'Byline Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-author' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_category_styles_author_color',
			[
				'label' => esc_html__( 'Byline Author Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-author span' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_category_margin',
			[
				'label' => esc_html__( 'Byline Margin', 'progression-elements-viseo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_category_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-viseo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-index-author',
			]
		);
		
		
		
		$this->end_controls_section();
		
		
		
		
		
		$this->start_controls_section(
			'section_styles_date_styles',
			[
				'label' => esc_html__( 'Meta Styles', 'progression-elements-viseo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'progression_elements_image_percent_color',
			[
				'label' => esc_html__( 'Percent Default Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .neo-progressbar' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_image_percent_color_selected',
			[
				'label' => esc_html__( 'Percent Selected Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .neo-progressbar > div' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_date_styles_color',
			[
				'label' => esc_html__( 'Meta Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-time-remaining' => 'color: {{VALUE}}',
					'{{WRAPPER}} .helpmeout-index-raised-percent' => 'color: {{VALUE}}',
					'{{WRAPPER}} .helpmeoutindex-fund-raised' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_date_styles_color_value',
			[
				'label' => esc_html__( 'Meta Value Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-time-remaining span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .helpmeout-index-raised-percent span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .helpmeoutindex-fund-raised span.helpmeoutindex-raised-heading' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_date_margin',
			[
				'label' => esc_html__( 'Meta Margin', 'progression-elements-viseo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-index-time-remaining,
{{WRAPPER}} .helpmeout-index-raised-percent,
{{WRAPPER}} .helpmeoutindex-fund-raised' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_date_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-viseo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-index-time-remaining, {{WRAPPER}} .helpmeout-index-raised-percent, {{WRAPPER}} .helpmeoutindex-fund-raised, {{WRAPPER}} .helpmeoutindex-fund-raised span.helpmeoutindex-raised-heading, {{WRAPPER}} .helpmeout-index-time-remaining span, {{WRAPPER}} .helpmeout-index-raised-percent span' ,
			]
		);
		
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_styles_cat_styles',
			[
				'label' => esc_html__( 'Category Styles', 'progression-elements-viseo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'progression_elements_cat_styles_color',
			[
				'label' => esc_html__( 'Category Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.helpmeout-progression-index-fund-cats a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_cat_styles_background_color',
			[
				'label' => esc_html__( 'Category Background', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.helpmeout-progression-index-fund-cats a' => 'background: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_cat_margin',
			[
				'label' => esc_html__( 'Category Padding', 'progression-elements-viseo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'.helpmeout-progression-index-fund-cats a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_cat_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-viseo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-progression-index-fund-cats a',
			]
		);
		
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_styles_read_more_styles',
			[
				'label' => esc_html__( 'Overlay Styles', 'progression-elements-viseo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'progression_elements_read_more_styles_overlay_hover_color',
			[
				'label' => esc_html__( 'Overlay Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-overlay' => 'background: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_read_more_styles_color',
			[
				'label' => esc_html__( 'Overlay Button Color', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-overlay span' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_read_more_styles_border',
			[
				'label' => esc_html__( 'Overlay Button Border', 'progression-elements-viseo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-overlay span' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_read_more_margin',
			[
				'label' => esc_html__( 'Overlay Button Padding', 'progression-elements-viseo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-overlay span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_read_more_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-viseo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-overlay span',
			]
		);
		
		
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_load_more_styles',
			[
				'label' => esc_html__( 'Load More Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'section_styles_load_more_icon',
			[
				'type' => Controls_Manager::ICON,
				'label_block' => true,
				'default' => 'fa-arrow-circle-down',
			]
		);
		
		$this->add_control(
			'section_styles_load_more_icon_indent',
			[
				'label' => esc_html__( 'Icon Spacing', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a span i' => 'margin-left: {{SIZE}}px;',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_load_more_padding',
			[
				'label' => esc_html__( 'Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_load_moretypography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .infinite-nav-pro a',
			]
		);
		
		
		
		
		$this->start_controls_tabs( 'boosted_elements_button_tabs' );

		$this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'background-color: {{VALUE}};',
				],
			]
		);

		
		$this->end_controls_tab();

		$this->start_controls_tab( 'boosted_elements_hover', [ 'label' => esc_html__( 'Hover', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_filter_styles',
			[
				'label' => esc_html__( 'Filtering Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_filtering_align',
			[
				'label' => esc_html__( 'Filtering Alignment', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group' => 'text-align: {{VALUE}}',
				],
			]
		);
		

		
		$this->add_control(
			'progression_elements_filter_font_color',
			[
				'label' => esc_html__( 'Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_filter_font_selected_color',
			[
				'label' => esc_html__( 'Selected Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li.pro-checked' => 'color: {{VALUE}}',
					'{{WRAPPER}} ul.progression-filter-button-group li:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_filter_border_color',
			[
				'label' => esc_html__( 'Default Border', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_filter_font_selected_border_color',
			[
				'label' => esc_html__( 'Selected Border', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li.pro-checked:after' => 'background: {{VALUE}}',
					'{{WRAPPER}} ul.progression-filter-button-group li:hover:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_fliltering_padding',
			[
				'label' => esc_html__( 'Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_fliltering_margin',
			[
				'label' => esc_html__( 'Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'Margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_filtering_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.progression-filter-button-group li',
			]
		);
		
		$this->end_controls_section();
		
	}
	

	protected function render() {
      	$settings = $this->get_settings();


		global $blogloop;
		global $post;
	
		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {   $paged = get_query_var('page'); } else {  $paged = 1; }
	

		$post_per_page = $settings['progression_main_post_count'];
		$offset = $settings['progression_main_offset_count'];
		$offset_new = $offset + (( $paged - 1 ) * $post_per_page);
	

		if ( ! empty( $settings['progression_slider_tags'] ) ) {
			$formatarray = $settings['progression_slider_tags']; // get custom field value
			
			$catarray = $settings['progression_slider_tags']; // get custom field value
			if($catarray >= 1 ) { 
				$catids = implode(', ', $catarray); 
			} else {
				$catids = '';
			}
			
			if($formatarray >= 1) { 
				$formatids = implode(', ', $formatarray);
			$formatidsexpand = explode(', ', $formatids);
				$formatoperator = 'IN'; 
			} else {
				$formatidsexpand = '';
				$formatoperator = 'NOT IN'; 
			}
			$operator = 'IN';
		} else {

				$formatidsexpand = '';
				$operator = 'NOT IN';
		}
	
	
		if($settings['progression_elements_post_featured'] == 'yes') {
		
			
			$args = array(
					'post_type'         => 'ignition_product',
					'orderby'         => $settings['progression_elements_post_order_sorting'],
					'order'         => $settings['progression_elements_post_order'],
					'posts_per_page'     =>  $post_per_page,
					'paged' => $paged,
					'offset' => $offset_new,
					'tax_query' => array(
						'relation' => 'AND',
						array(
							'taxonomy' => 'project_category',
							'field'    => 'id',
							'terms'    => $formatidsexpand,
								'operator' => $operator
						),
						array(
							'taxonomy' => 'product_visibility',
							'field'    => 'name',
							'terms'    => 'featured',
							'operator' => 'IN'
						),
					),
			);
			
		} else {
			
			$args = array(
					'post_type'         => 'ignition_product',
					'orderby'         => $settings['progression_elements_post_order_sorting'],
					'order'         => $settings['progression_elements_post_order'],
					'posts_per_page'     =>  $post_per_page,
					'paged' => $paged,
					'offset' => $offset_new,
					'tax_query' => array(
						array(
							'taxonomy' => 'project_category',
							'field'    => 'id',
							'terms'    => $formatidsexpand,
								'operator' => $operator
						),
					),
			);
		
		}
	
 	

		$blogloop = new \WP_Query( $args );
?>
	
	<div class="progression-studios-elementor-crowdfunding-container woocommerce">
		
			<?php if($settings['progression_elements_slider_sorting_on'] == 'yes' ): ?>
				<ul class="progression-filter-button-group progression-filter-group-<?php echo esc_attr($this->get_id()); ?><?php if($settings['boosted_elements_filtering_align'] == 'center' ): ?> progression-centered-filte-filter-pro<?php endif ?>">
					<?php if($settings['progression_slider_tags']): ?>
						<?php
							$i = 0;
							$args = array(
							    'hide_empty'             => '0',
							    'include'              => $catids,
							); 
							$terms = get_terms( 'product_cat', $args );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
								echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
			
								foreach ( $terms as $term ) { 
								if ($i == 0) {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								} else if ($i > 0)  {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								}
								$i++;
								}
							}	
						?>
					<?php else : ?>
						<?php
							$i = 0;
							$terms = get_terms( 'product_cat', 'hide_empty=0' );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
								echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
				
								foreach ( $terms as $term ) { 
								if ($i == 0) {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								} else if ($i > 0)  {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								}
								$i++;
								}
							}	
						?>
					<?php endif ?>
				</ul>
			
				<div class="clearfix-pro"></div>
			<?php endif ?>
	
		
		<div class="progression-masonry-margins">
			<ul id="progression-crowfunding-index-masonry-<?php echo esc_attr($this->get_id()); ?>" class="products">
				<?php while($blogloop->have_posts()): $blogloop->the_post();?>
					
				<li class="product progression-masonry-item <?php $terms = get_the_terms( $post->ID , 'product_cat' ); if ( !empty( $terms ) ) : foreach ( $terms as $term ) { 	$term_link = get_term_link( $term, 'product_cat' ); if( is_wp_error( $term_link ) ) continue; echo " ". $term->slug ; }  endif; ?> <?php if($settings['progression_elements_post_list_cat'] != 'yes' ): ?> progression_elements_post_list_cat<?php endif ?><?php if($settings['progression_elements_post_list_author'] != 'yes' ): ?> progression_elements_post_list_author<?php endif ?><?php if($settings['progression_elements_post_list_date'] != 'yes' ): ?>progression_elements_post_list_date<?php endif ?>">
					<div class="progression-masonry-padding-blog">
						<div class="progression-studios-isotope-animation">
							
							<?php include(locate_template('template-parts/elementor/content-project.php')); ?>
							
						</div><!-- close .progression-studios-isotope-animation -->
					</div><!-- close .progression-masonry-padding-blog -->
				</li><!-- close .progression-masonry-item -->
				<?php  endwhile; // end of the loop. ?>
			</ul><!-- close #progression-crowfunding-index-masonry-<?php echo esc_attr($this->get_id()); ?>  -->
		</div><!-- close .progression-masonry-margins -->
		
		<div class="clearfix-pro"></div>
				<?php if ( $settings['progression_elements_post_list_pagination'] == 'default' ) : ?>
					<?php
			
						$page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page);
			
					if ( $page_tot > 1 ) {
						$big        = 999999999;
						echo paginate_links( array(
							'base'      => str_replace( $big, '%#%',get_pagenum_link( 999999999, false ) ), // need an unlikely integer cause the url can contains a number
							'format'    => '?paged=%#%',
							'current'   => max( 1, $paged ),
							'total'     => ceil(($blogloop->found_posts - $offset) / $post_per_page),
							'prev_next' => true,
								'prev_text'    => esc_html__('&lsaquo; Previous', 'progression-elements-multifondo'),
								'next_text'    => esc_html__('Next &rsaquo;', 'progression-elements-multifondo'),
							'end_size'  => 1,
							'mid_size'  => 2,
							'type'      => 'list'
						));
					}
					?>
				<?php endif; ?>

				<?php if ( $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
			
						<?php $page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page); if ( $page_tot > 1 ) : ?>
						<div id="progression-load-more-manual">
							<div id="infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>" class="infinite-nav-pro">
								<div class="nav-previous"><?php next_posts_link( $settings['progression_main_post_load_more'] . '<span><i class="fa ' . $settings['section_styles_load_more_icon'] . '"></i></span>', $blogloop->max_num_pages ); ?>
								</div>
							</div>
						</div>
					<?php endif ?>
				<?php endif; ?>
	
				<?php if ( $settings['progression_elements_post_list_pagination'] == 'infinite-scroll' ) : ?>
					<?php $page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page); 
					
					if ( $page_tot > 1 ) : ?>
						<div id="infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>" class="infinite-nav-pro">
							<div class="nav-previous"><?php next_posts_link( 'Next', $blogloop->max_num_pages ); ?>
							</div>
						</div>
					<?php endif ?>
				<?php endif; ?>
		
	</div><!-- close .progression-studios-elementor-crowdfunding-container -->
	
	<div class="clearfix-pro"></div>
	
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		'use strict';
		/* Default Isotope Load Code */
		var $container<?php echo esc_attr($this->get_id()); ?> = $("#progression-crowfunding-index-masonry-<?php echo esc_attr($this->get_id()); ?>").isotope();
		$container<?php echo esc_attr($this->get_id()); ?>.imagesLoaded( function() {
			$(".progression-masonry-item").addClass("opacity-progression");
			$container<?php echo esc_attr($this->get_id()); ?>.isotope({
				itemSelector: "#progression-crowfunding-index-masonry-<?php echo esc_attr($this->get_id()); ?> .progression-masonry-item",				
				percentPosition: true,
				layoutMode: <?php if ( ! empty( $settings['boosted_post_list_masonry'] ) ) : ?>"masonry"<?php else: ?>"fitRows"<?php endif; ?> 
	 		});
		});
		/* END Default Isotope Code */
		
		<?php if( $settings['progression_elements_slider_sorting_on'] == 'yes'): ?>
		$('.progression-filter-group-<?php echo esc_attr($this->get_id()); ?>').on( 'click', 'li', function() {
		  var filterValue = $(this).attr('data-filter');
		  $container<?php echo esc_attr($this->get_id()); ?>.isotope({ filter: filterValue });
		});
		
    	  $('.progression-filter-group-<?php echo esc_attr($this->get_id()); ?>').each( function( i, buttonGroup ) {
    		var $buttonGroup = $( buttonGroup );
    		$buttonGroup.on( 'click', 'li', function() {
    		  $buttonGroup.find('.pro-checked').removeClass('pro-checked');
    		  $( this ).addClass('pro-checked');
    		});
    	  });
		<?php endif ?>
		
		
		<?php if ( $settings['progression_elements_post_list_pagination'] == 'infinite-scroll' || $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
		
		/* Begin Infinite Scroll */
		$container<?php echo esc_attr($this->get_id()); ?>.infinitescroll({
		errorCallback: function(){  $("#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>").delay(500).fadeOut(500, function(){ $(this).remove(); }); },
		  navSelector  : "#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>",  
		  nextSelector : "#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?> .nav-previous a", 
		  itemSelector : "#progression-crowfunding-index-masonry-<?php echo esc_attr($this->get_id()); ?> .progression-masonry-item", 
	   		loading: {
	   		 	img: "<?php echo esc_url( get_template_directory_uri() );?>/images/loader.gif",
	   			 msgText: "",
	   		 	finishedMsg: "<div id='no-more-posts'></div>",
	   		 	speed: 0, }
		  },
		  // trigger Isotope as a callback
		  function( newElements ) {
		    var $newElems = $( newElements );
 	
				$newElems.imagesLoaded(function(){
					
				$container<?php echo esc_attr($this->get_id()); ?>.isotope( "appended", $newElems );
				$(".progression-masonry-item").addClass("opacity-progression");
				
			});

		  }
		);
	    /* END Infinite Scroll */
		<?php endif; ?>
		
		
		<?php if ( $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
		/* PAUSE FOR LOAD MORE */
		$(window).unbind(".infscr");
		// Resume Infinite Scroll
		$("#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?> .nav-previous a").click(function(){
			$container<?php echo esc_attr($this->get_id()); ?>.infinitescroll("retrieve");
			return false;
		});
		/* End Infinite Scroll */
		<?php endif; ?>
		
	});
	</script>
	

	<?php wp_reset_postdata();?>
	

	<?php
	
	}

	protected function content_template() {
		
		?>

		<?php
	}
}


Plugin::instance()->widgets_manager->register_widget_type( new Widget_ProgressionElementsCrowdFundingList() );