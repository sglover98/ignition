<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.


class Widget_ProgressionElementsCrowdFundingSlider extends Widget_Base {

	public function get_name() {
		return 'progression-studios-crowdfunding-slider';
	}

	public function get_title() {
		return esc_html__( 'Crowdfunding Slider', 'progression-elements-multifondo' );
	}

	public function get_icon() {
		return 'eicon-slideshow progression-studios-soundbyte-pe';
	}

   public function get_categories() {
		return [ 'progression-studios-helpmeout' ];
	}
	
	function Widget_ProgressionElementsCrowdFundingSlider($widget_instance){
		
	}
	
	protected function _register_controls() {
		
		

  		$this->start_controls_section(
  			'section_title_global_options',
  			[
  				'label' => esc_html__( 'Slider Settings', 'progression-elements-multifondo' )
  			]
  		);
		
		$this->add_control(
			'progression_main_post_count',
			[
				'label' => esc_html__( 'Post Count', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '3',
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_featured',
			[
				'label' => esc_html__( 'Featured Products', 'progression-elements-multifondo' ),
				'description' => esc_html__( 'Display featured products only', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_slider_tags',
			[
				'label' => esc_html__( 'Narrow by Category', 'progression-elements-multifondo' ),
				'description' => esc_html__( 'Choose a category to display projects', 'progression-elements-multifondo' ),
				'label_block' => true,
				'multiple' => true,
				'type' => Controls_Manager::SELECT2,
				'options' => helpmeout_elements_post_type_categories(),
			]
		);
		


		
		
		$this->add_control(
			'progression_elements_post_order_sorting',
			[
				'label' => esc_html__( 'Order By', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date' => esc_html__( 'Default - Date', 'progression-elements-multifondo' ),
					'title' => esc_html__( 'Post Title', 'progression-elements-multifondo' ),
					'menu_order' => esc_html__( 'Menu Order', 'progression-elements-multifondo' ),
					'modified' => esc_html__( 'Last Modified', 'progression-elements-multifondo' ),
					'comment_count' => esc_html__( 'Comment Count', 'progression-elements-multifondo' ),
					'rand' => esc_html__( 'Random', 'progression-elements-multifondo' ),
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_order',
			[
				'label' => esc_html__( 'Order', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC' => esc_html__( 'Ascending', 'progression-elements-multifondo' ),
					'DESC' => esc_html__( 'Descending', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_main_offset_count',
			[
				'label' => esc_html__( 'Offset Count', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '0',
				'description' => esc_html__( 'Use this to skip over posts (Example: 3 would skip the first 3 posts.)', 'progression-elements-multifondo' ),
			]
		);
		
		

		
		$this->end_controls_section();

		
  		
		
		
  		$this->start_controls_section(
  			'section_title_boosted_slider_options',
  			[
  				'label' => esc_html__( 'Slider Options', 'progression-elements-multifondo' )
  			]
  		);
		
		$this->add_responsive_control(
			'progression_elements_slider_main_height',
			[
				'label' => esc_html__( 'Slider Height', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 760,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 1500,
					],
					'vh' => [
						'min' => 10,
						'max' => 150,
					],
				],
				'size_units' => [ 'px', 'vh', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .progression-elements-slider-background' => 'height:{{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_slider_transition',
			[
				'label' => esc_html__( 'Slide Transition', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'fade',
				'options' => [
					'fade' => esc_html__( 'Fade', 'progression-elements-multifondo' ),
					'slide' => esc_html__( 'Slide', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_elements_slide_transition_speed',
			[
				'label' => esc_html__( 'Transition Speed', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '800',
			]
		);
		
		$this->add_control(
			'progression_elements_slider_css3_animation',
			[
				'label' => esc_html__( 'Text Animation', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'progression_animate_none',
				'options' => [
					'progression_animate_none' => esc_html__( 'No Animation', 'progression-elements-multifondo' ),
					'progression_animate_in' => esc_html__( 'Zoom In', 'progression-elements-multifondo' ),
					'progression_animate_out' => esc_html__( 'Zoom Out', 'progression-elements-multifondo' ),
					'progression_animate_up' => esc_html__( 'Fade Delay', 'progression-elements-multifondo' ),
					'progression_animate_up' => esc_html__( 'Fade Up', 'progression-elements-multifondo' ),
					'bosted_animate_down' => esc_html__( 'Fade Down', 'progression-elements-multifondo' ),
					'progression_animate_right' => esc_html__( 'Fade Right', 'progression-elements-multifondo' ),
					'progression_animate_left' => esc_html__( 'Fade Left', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_elements_autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_play_number_speed',
			[
				'label' => esc_html__( 'Autoplay Speed', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '7500'
			]
		);
		
		
		$this->add_control(
			'progression_elements_slider_pause_hover',
			[
				'label' => esc_html__( 'Pause on Hover', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_slider_arrow_visiblity',
			[
				'label' => esc_html__( 'Slide Arrows', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'progression_elements_slider_arrow_visiblity_hover',
				'options' => [
					'progression_elements_slider_arrow_visiblity_visible' => esc_html__( 'Always Visible', 'progression-elements-multifondo' ),
					'progression_elements_slider_arrow_visiblity_hover' => esc_html__( 'Visible on Hover', 'progression-elements-multifondo' ),
					'progression_elements_slider_arrow_visiblity_hidden' => esc_html__( 'Hidden', 'progression-elements-multifondo' ),
				],
			]
		);
		
		$this->add_control(
			'progression_elements_slider_bullets_visiblity',
			[
				'label' => esc_html__( 'Slide Bullets', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'progression_elements_slider_dots_visiblity_visible',
				'options' => [
					'progression_elements_slider_dots_visiblity_visible' => esc_html__( 'Always Visible', 'progression-elements-multifondo' ),
					'progression_elements_slider_dots_visiblity_hover' => esc_html__( 'Visible on Hover', 'progression-elements-multifondo' ),
					'progression_elements_slider_dots_visiblity_hidden' => esc_html__( 'Hidden', 'progression-elements-multifondo' ),
				],
			]
		);
		

		
		$this->end_controls_section();
		
		
		
		
  		$this->start_controls_section(
  			'section_title_boosted_post_layout',
  			[
  				'label' => esc_html__( 'Post Layout', 'progression-elements-multifondo' )
  			]
  		);
		
		
		$this->add_control(
			'progression_elements_post_show_cat',
			[
				'label' => esc_html__( 'Shop Category', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_short_description',
			[
				'label' => esc_html__( 'Shop  Short Description', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_showbyline',
			[
				'label' => esc_html__( 'Shop  Byline', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_percent_text',
			[
				'label' => esc_html__( 'Shop Percentage Text', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_percent',
			[
				'label' => esc_html__( 'Shop Percentage', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_raised',
			[
				'label' => esc_html__( 'Shop Raised', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_goal',
			[
				'label' => esc_html__( 'Shop Goal', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		

		$this->add_control(
			'progression_elements_post_display_time_remaining',
			[
				'label' => esc_html__( 'Shop Time Remaining', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_main_post_play_more_btn',
			[
				'label' => esc_html__( 'Read More Text', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'View Project',
			]
		);
		
		
		$this->end_controls_section();
		
		
		
		
		$this->start_controls_section(
			'boosted_elements_section_main_styles',
			[
				'label' => esc_html__( 'Main Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		

		
		
		$this->add_responsive_control(
			'boosted_elements_content_width',
			[
				'label' => esc_html__( 'Text Width', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ '%', 'px' ],
				'default' => [
					'size' => '800',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-content-max-width' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_container_width',
			[
				'label' => esc_html__( 'Container Max Width', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ '%', 'px' ],
				'default' => [
					'size' => '100',
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-container-max-width' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_content_padding',
			[
				'label' => esc_html__( 'Content Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-content-margins' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_content_align',
			[
				'label' => esc_html__( 'Text Align', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-content-alignment' => 'text-align: {{VALUE}}',
				],
			]
		);
	
		$this->add_responsive_control(
			'boosted_elements_vertical_position',
			[
				'label' => esc_html__( 'Vertical Position', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'default' => 'middle',
				'options' => [
					'top' => [
						'title' => esc_html__( 'Top', 'progression-elements-multifondo' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'progression-elements-multifondo' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'progression-elements-multifondo' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-text-floating-container' => '{{VALUE}}',
				],
				'selectors_dictionary' => [
					'top' => 'display:block;',
					'middle' => 'display:table-cell; vertical-align:middle;',
					'bottom' => 'position:absolute; bottom:0px;',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_horizontal_position',
			[
				'label' => esc_html__( 'Horizontal Position', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'progression-elements-multifondo' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-slider-content-floating-container' => '{{VALUE}}',
				],
				'selectors_dictionary' => [
					'left' => 'float:left;',
					'center' => '',
					'right' => 'float:right;',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'helpmeout_elements_background_overlay',
				'types' => [ 'classic', 'gradient' ],
				'separator' => 'before',
				'selector' => '{{WRAPPER}} .slider-background-overlay-color',
			]
		);
		

		$this->end_controls_section();
		
		
		
		
		
		
		
		$this->start_controls_section(
			'section_styles_category_styles',
			[
				'label' => esc_html__( 'Title Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'progression_elements_category_styles_color',
			[
				'label' => esc_html__( 'Title Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.helpmeout-progression-slider-title a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_category_styles_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.helpmeout-progression-slider-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_category_margin',
			[
				'label' => esc_html__( 'Title Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} h2.helpmeout-progression-slider-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_category_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} h2.helpmeout-progression-slider-title',
			]
		);
		
		
		
		$this->end_controls_section();
		
		
		
		
		$this->start_controls_section(
			'section_styles_sub_title_styles',
			[
				'label' => esc_html__( 'Short Description Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'progression_elements_sub_title_styles_color',
			[
				'label' => esc_html__( 'Short Description Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-sub-title' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_responsive_control(
			'progression_elements_sub_title_margin',
			[
				'label' => esc_html__( 'Short Description Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_sub_title_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-progression-slider-sub-title',
			]
		);
		
		
		
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_title_styles',
			[
				'label' => esc_html__( 'Meta Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_percent_width',
			[
				'label' => esc_html__( 'Percent Width', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 800,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ '%', 'px' ],
				'default' => [
					'size' => '100',
					'unit' => '%',
				],
				'size_units' => [  'px', '%' ],
				'default' => [
					'size' => '100',
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-raised-bar' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_percent_height',
			[
				'label' => esc_html__( 'Percent Height', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '8',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-raised-bar .neo-progressbar > div' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_title_styles_percent_color',
			[
				'label' => esc_html__( 'Percent Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-raised-bar .neo-progressbar' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_title_styles_percent_background',
			[
				'label' => esc_html__( 'Percent Backgrond', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-raised-bar .neo-progressbar > div' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_title_percent_typography',
			[
				'label' => esc_html__( 'Percent Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'after',
				
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-raised-bar.wpneo-raised-bar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_title_styles_color',
			[
				'label' => esc_html__( 'Meta Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-author, {{WRAPPER}}  .helpmeout-slider-time-remaining, {{WRAPPER}}  .helpmeout-progression-slider-raised-percent, {{WRAPPER}} .helpmeout-progression-slider-fund-raised' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_title_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'separator' => 'after',
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .helpmeout-progression-slider-author, {{WRAPPER}}  .helpmeout-slider-time-remaining, {{WRAPPER}}  .helpmeout-progression-slider-raised-percent, {{WRAPPER}}  .helpmeout-progression-slider-fund-raised',
			]
		);

		
		$this->add_responsive_control(
			'progression_elements_title_margin',
			[
				'label' => esc_html__( 'Meta Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-author, {{WRAPPER}}  .helpmeout-slider-time-remaining, {{WRAPPER}}  .helpmeout-progression-slider-raised-percent, {{WRAPPER}} .helpmeout-progression-slider-fund-raised' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_title_styles_hover_color',
			[
				'label' => esc_html__( 'Meta Value Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} span.helpmeout-slider-meta-days-remaining, {{WRAPPER}}  span.helpmeout-progression-slider-meta-percent, {{WRAPPER}}  span.helpmeout-progression-slider-raised-heading' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_meta_title_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} span.helpmeout-slider-meta-days-remaining, {{WRAPPER}}  span.helpmeout-progression-slider-meta-percent, {{WRAPPER}}  span.helpmeout-progression-slider-raised-heading',
			]
		);
		
		
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'boosted_elements_section_button_typography_styles',
			[
				'label' => esc_html__( 'Content Button', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'selector' => '{{WRAPPER}} a.helpmeout-progression-slider-view-project',
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_4,
			]
		);
		
		$this->add_control(
			'boosted_elements_button_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		

		
		
		
		
		$this->add_responsive_control(
			'boosted_elements_main_button_padding',
			[
				'label' => esc_html__( 'Button Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		
		$this->start_controls_tabs( 'boosted_elements_button_tabs' );

		$this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project' => 'color: {{VALUE}};',
				],
			]
		);
		

		$this->add_control(
			'boosted_elements_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'boosted_elements_button_border_width_new',
				'selector' => '{{WRAPPER}}  a.helpmeout-progression-slider-view-project',
			]
		);
		
		
		$this->end_controls_tab();

		$this->start_controls_tab( 'boosted_elements_hover', [ 'label' => esc_html__( 'Hover', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.helpmeout-progression-slider-view-project:hover' => 'border-color: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		
		


		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'boosted_elements_section_button_second_typography_styles',
			[
				'label' => esc_html__( 'Category', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_secondary_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-multifondo' ),
				'selector' => '{{WRAPPER}} .helpmeout-progression-slider-fund-cats a',
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
			]
		);
		
		$this->add_control(
			'boosted_elements_button_margins',
			[
				'label' => esc_html__( 'Category Margin', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .boosted-elements-slider-content .boosted-elements-slide-button-main' => 'margin-right: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'boosted_elements_second_button_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		

		
		
		$this->add_responsive_control(
			'boosted_elements_main_alterantive_button_padding',
			[
				'label' => esc_html__( 'Category Padding', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->start_controls_tabs( 'boosted_elements_secondary_button_tabs' );

		$this->start_controls_tab( 'secondary_normal', [ 'label' => esc_html__( 'Normal', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_secondary_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a' => 'color: {{VALUE}};',
				],
			]
		);
		

		
		$this->add_control(
			'boosted_elements_secondary_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'boosted_elements_second_button_border_width_new',
				'selector' => '{{WRAPPER}}  .helpmeout-progression-slider-fund-cats a',
			]
		);
		
		
		
		$this->end_controls_tab();

		$this->start_controls_tab( 'boosted_elements_secondary_hover', [ 'label' => esc_html__( 'Hover', 'progression-elements-multifondo' ) ] );

		$this->add_control(
			'boosted_elements_secondary_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_secondary_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_secondary_button_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .helpmeout-progression-slider-fund-cats a:hover' => 'border-color: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		$this->end_controls_section();
		

		
		
		
		
		$this->start_controls_section(
			'section_styles_nav_styles',
			[
				'label' => esc_html__( 'Navigation Styles', 'progression-elements-multifondo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'progression_elements_nav_arrow_color',
			[
				'label' => esc_html__( 'Arrow Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-post-slider-main .flex-direction-nav a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_nav_arrow_hover_color',
			[
				'label' => esc_html__( 'Arrow Hover Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-post-slider-main .flex-direction-nav a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		
		$this->add_control(
			'progression_elements_nav_bullet_color',
			[
				'label' => esc_html__( 'Bullet Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-post-slider-main  .flex-control-paging li a' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_nav_bullet_hover_color',
			[
				'label' => esc_html__( 'Bullet Selected Color', 'progression-elements-multifondo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-post-slider-main .flex-control-paging li a.flex-active' => 'background: {{VALUE}}',
				],
			]
		);
		

		
		$this->end_controls_section();
		
		
		
	}
	

	protected function render( ) {
		
      $settings = $this->get_settings();
		
	?>
	
	<?php	
		global $blogloop;
		global $post;

		
		$post_per_page = $settings['progression_main_post_count'];
		$offset_new = $settings['progression_main_offset_count'];

		
		if ( ! empty( $settings['progression_slider_tags'] ) ) {
			$formatarray = $settings['progression_slider_tags']; // get custom field value
			
			$catarray = $settings['progression_slider_tags']; // get custom field value
			if($catarray >= 1 ) { 
				$catids = implode(', ', $catarray); 
			} else {
				$catids = '';
			}
			
			if($formatarray >= 1) { 
				$formatids = implode(', ', $formatarray);
			$formatidsexpand = explode(', ', $formatids);
				$formatoperator = 'IN'; 
			} else {
				$formatidsexpand = '';
				$formatoperator = 'NOT IN'; 
			}
			$operator = 'IN';
		} else {

				$formatidsexpand = '';
				$operator = 'NOT IN';
		}
	
	
		if($settings['progression_elements_post_featured'] == 'yes') {
			$args = array(
					'post_type'         => 'ignition_product',
					'orderby'         => $settings['progression_elements_post_order_sorting'],
					'order'         => $settings['progression_elements_post_order'],
					'ignore_sticky_posts' => 1,
					'posts_per_page'     =>  $post_per_page,
					'offset' => $offset_new,
					'tax_query' => array(
						'relation' => 'AND',
						array(
							'taxonomy' => 'project_category',
							'field'    => 'id',
							'terms'    => $formatidsexpand,
								'operator' => $operator
						),
						array(
							'taxonomy' => 'product_visibility',
							'field'    => 'name',
							'terms'    => 'featured',
							'operator' => 'IN'
						),
					),
			);
			
		} else {
			$args = array(
					'post_type'         => 'ignition_product',
					'orderby'         => $settings['progression_elements_post_order_sorting'],
					'order'         => $settings['progression_elements_post_order'],
					'ignore_sticky_posts' => 1,
					'posts_per_page'     =>  $post_per_page,
					'offset' => $offset_new,
					'tax_query' => array(
						array(
							'taxonomy' => 'project_category',
							'field'    => 'id',
							'terms'    => $formatidsexpand,
								'operator' => $operator
						)
					),
			);
		}
 	
	
		$blogloop = new \WP_Query( $args );

	?>
	

	<div class="progression-studios-post-slider-main <?php echo esc_attr($settings['progression_elements_slider_arrow_visiblity'] ); ?> <?php echo esc_attr($settings['progression_elements_slider_bullets_visiblity'] ); ?>">
		<div id="progression-elements-progression-flexslider-<?php echo esc_attr($this->get_id()); ?>" class="flexslider">
			<ul class="slides">
				<?php while($blogloop->have_posts()): $blogloop->the_post();?>
					<?php include(locate_template('template-parts/elementor/content-slider.php')); ?>
				<?php  endwhile; // end of the loop. ?>
			</ul>
		</div><!-- #-elements-progression-flexslider-<?php echo esc_attr($this->get_id()); ?> -->
	</div><!-- close .progression-studios-post-slider-main -->
	
	
	<?php wp_reset_postdata();?>
	
	<script type="text/javascript"> 
		jQuery(document).ready(function($) {
			'use strict';
			
		$('#progression-elements-progression-flexslider-<?php echo esc_attr($this->get_id()); ?>').flexslider({
				prevText: "",
				nextText: "",
				slideshow:<?php if ( ! empty( $settings['progression_elements_autoplay'] ) ) : ?>true<?php else: ?>false<?php endif; ?>,
				slideshowSpeed: <?php echo esc_attr($settings['progression_elements_play_number_speed'] ); ?>,
				animation: "<?php echo esc_attr($settings['progression_elements_slider_transition'] ); ?>",
				animationSpeed: <?php echo esc_attr($settings['progression_elements_slide_transition_speed'] ); ?>,
				pauseOnHover: <?php if ( ! empty( $settings['progression_elements_slider_pause_hover'] ) ) : ?>true<?php else: ?>false<?php endif; ?>,
		});
			

		});
	</script>
	

	<?php
	
	}

	protected function content_template() {
		
		?>

		<?php
	}
}


Plugin::instance()->widgets_manager->register_widget_type( new Widget_ProgressionElementsCrowdFundingSlider() );