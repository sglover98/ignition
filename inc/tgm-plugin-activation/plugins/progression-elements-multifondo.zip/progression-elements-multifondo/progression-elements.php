<?php
/*
Plugin Name: Progression Theme Elements - Multifundo
Text Domain: progression-elements-multifondo
Plugin URI: https://progressionstudios.com
Description: Theme Elements for Progression Studios Theme
Version: 1.4
Author: Progression Studios
Author URI: https://progressionstudios.com/
Author Email: contact@progressionstudios.com
License: GNU General Public License v3.0
Text Domain: progression-elements-multifondo
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.


define( 'PROGRESSION_THEME_ELEMENTS_URL', plugins_url( '/', __FILE__ ) );
define( 'PROGRESSION_THEME_ELEMENTS_PATH', plugin_dir_path( __FILE__ ) );


// Translation Setup
add_action('plugins_loaded', 'progression_theme_elements_helpmeout');
function progression_theme_elements_helpmeout() {
	load_plugin_textdomain( 'progression-elements-multifondo', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
	remove_action( 'wp_head', 'wpneo_custom_css' );// Removing CrowdFunding Custom CSS menu-settings.php
}



/* Remove Jetpack Sharing Icons so I can manually add them into post */
function progresion_studios_move_jp_sharing( $content ) {
	if ( is_singular( 'post' ) && function_exists( 'sharing_display' )  ) {
		remove_filter( 'the_content', 'sharing_display', 19 );
	}
	return $content;
}
add_filter( 'the_content', 'progresion_studios_move_jp_sharing' );


// CSS Styles in Admin
function progression_theme_helpmeout_elements_wp_admin_style() {
    wp_register_style( 'progression-elements-multifondo-admin-styles',  PROGRESSION_THEME_ELEMENTS_URL . 'assets/css/style.css' );
    wp_enqueue_style( 'progression-elements-multifondo-admin-styles' );
    wp_enqueue_script( 'progression_studios_import_data', plugin_dir_url( __FILE__ ) . 'assets/js/importdata.js' );


}
add_action( 'admin_enqueue_scripts', 'progression_theme_helpmeout_elements_wp_admin_style' );





/**
* Enqueue or de-enqueue third party plugin scripts/styles
*/
function progression_helpmeout_theme_elements_dequeue_styles_scripts() {
     wp_deregister_script( 'boosted_elements_progression_flexslider_js' ); //Removing a script
	  wp_deregister_style( 'neo-crowdfunding-css-front' );// Removing CrowdFunding CSS menu-settings.php
	  wp_deregister_script( 'boosted_elements_progression_masonry_js' ); //Removing a script
	  wp_deregister_style( 'jquery-ui' );// Removing CrowdFunding UI for SSL Support
	  wp_deregister_style( 'ssl-supported-jquery-ui' );
	  wp_register_style('ssl-supported-jquery-ui', '//ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css');
}
add_action( 'wp_enqueue_scripts', 'progression_helpmeout_theme_elements_dequeue_styles_scripts', 100 );





// Calling new Page Builder Elements
require_once PROGRESSION_THEME_ELEMENTS_PATH.'inc/elementor-helper.php';

function progression_soundbyte_elements_load_elements(){
	require_once PROGRESSION_THEME_ELEMENTS_PATH.'elements/slider-element.php';
	require_once PROGRESSION_THEME_ELEMENTS_PATH.'elements/post-element.php';
}
add_action('elementor/widgets/widgets_registered','progression_soundbyte_elements_load_elements');


/**
 * Custom Submit Form
 */

require PROGRESSION_THEME_ELEMENTS_PATH.'inc/crowdfunding-custom.php';
require PROGRESSION_THEME_ELEMENTS_PATH.'inc/start-a-project-form.php';


/**
 * Custom Metabox Fields
 */
require PROGRESSION_THEME_ELEMENTS_PATH.'inc/custom-meta.php';

