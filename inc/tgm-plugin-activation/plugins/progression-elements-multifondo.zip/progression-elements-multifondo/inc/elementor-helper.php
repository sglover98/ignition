<?php
namespace Elementor;

function progression_soundbyte_elements_elementor_init(){
    Plugin::instance()->elements_manager->add_category(
        'progression-studios-helpmeout',
        [
            'title'  => 'Multifondo Addons',
            'icon' => 'font'
        ],
        1
    );
}
add_action('elementor/init','Elementor\progression_soundbyte_elements_elementor_init');




//Query Categories List
function helpmeout_elements_post_type_categories(){
	//https://developer.wordpress.org/reference/functions/get_terms/
	$terms = get_terms( array( 
		'taxonomy' => 'project_category',
		'hide_empty' => true,
	));
	
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
	foreach ( $terms as $term ) {
		$options[ $term->term_id ] = $term->name;
	}
	}
	
	return $options;
}

