<?php


if (! function_exists('wpneo_crowdfunding_form')) {
function wpneo_crowdfunding_form( $atts ) {
    global $post, $wpdb;

    $html = '';
    $title = $description = $short_description = $category = $tag = $image_url = $image_id = $video = $start_date = $end_date = $minimum_price = $maximum_price = $recomended_price = $funding_goal = $campaign_end_method = $type = $contributor_show = $paypal = $country = $location = $edit_form = $edit_id = $checked = $checked2 = '';

    $reward = '';
    if(isset($_GET['action'])){
        if($_GET['action']=='edit'){
            $post_id = (int) sanitize_text_field($_GET['postid']);

            //Prevent if unauthorised access
            $campaign_users = new WPNEO_Frontend_Campaign_Submit_Form();
            $wp_query_users_product_id = $campaign_users->logged_in_user_campaign_ids();
            if ( ! in_array($post_id, $wp_query_users_product_id)){

                $html.= '<header class="wpneo-page-header">';
                $html.= '<h1 class="wpneo-page-title">'. __( 'Not Found', 'progression-elements-multifondo' ) .'</h1>';
                $html .= '</header>';
                $html .= '<h2 class="wpneo-subtitle">'. __( 'This is somewhat embarrassing, isn’t it?', 'progression-elements-multifondo' ) .'</h2>';
                $html .= '<p>'. __( 'It looks like nothing was found at this location. Maybe try a search?', 'progression-elements-multifondo' ) .'</p>';
                $html .= get_search_form( false );

                return $html;
            }

            $args = array(
                'p' => $post_id,
                'post_type' => 'product'
            );
            $the_query = new WP_Query( $args );
            if ( $the_query->have_posts() ) {
                while ( $the_query->have_posts() ) {
                    $the_query->the_post();
                    if( $post->post_author == get_current_user_id() ){

                        $title              = get_the_title();
                        $short_description  = get_the_excerpt();
                        $description        = get_the_content();
                        $category           = strip_tags(get_the_term_list( get_the_ID(), 'product_cat', '', ','));
                        $tag                = strip_tags( get_the_term_list( get_the_ID(), "product_tag","",", ") );
                        if ( has_post_thumbnail() ) {
                            $image_url          = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
                            $image_url          = $image_url[0];
                            $image_id           = get_post_thumbnail_id( get_the_ID() );
                        }
                        $video              = get_post_meta( get_the_ID(), 'wpneo_funding_video', true );
                        $start_date         = get_post_meta( get_the_ID(), '_nf_duration_start', true );
                        $end_date           = get_post_meta( get_the_ID(), '_nf_duration_end', true );
                        $minimum_price      = get_post_meta( get_the_ID(), 'wpneo_funding_maximum_price', true );
                        $maximum_price      = get_post_meta( get_the_ID(), 'wpneo_funding_minimum_price', true );
                        $recomended_price   = get_post_meta( get_the_ID(), 'wpneo_funding_recommended_price', true );
                        $funding_goal       = get_post_meta( get_the_ID(), '_nf_funding_goal', true );
                        $campaign_end_method = get_post_meta(get_the_ID(), 'wpneo_campaign_end_method', true);
                        $type               = get_post_meta( get_the_ID(), 'wpneo_show_contributor_table', true );
                        $contributor_show   = get_post_meta( get_the_ID(), 'wpneo_mark_contributors_as_anonymous', true );
                        $paypal             = get_post_meta( get_the_ID(), 'wpneo_campaigner_paypal_id', true );
                        $country            = get_post_meta( get_the_ID(), 'wpneo_country', true );
                        $location           = get_post_meta( get_the_ID(), '_nf_location', true );
                        $reward             = get_post_meta( get_the_ID(), 'wpneo_reward', true );
                        $edit_form          = '<input type="hidden" name="edit_form" value="editform"/>';
                        $edit_id            = '<input type="hidden" name="edit_post_id" value="'.$_GET["postid"].'"/>';

                    }
                }
            }
            wp_reset_postdata();
        }
    }

    //Protect this page from Guest user
    if (!is_user_logged_in()){
	 	$notify_text 	= wp_kses( __('Please <a href="%s">login</a> or <a href="%s">register for a new account</a> in order to start a project.', 'progression-elements-multifondo' ) , TRUE);
	 	$login_url 		= get_permalink( wc_get_page_id( 'myaccount' ) );
	 	$register_url 	= get_permalink( wc_get_page_id( 'myaccount' ) ); //get_page_link (get_option('wpneo_registration_page_id','') );
	
	 	$html = '<div class="helpmout-notification-login"><i class="fa fa-lock"></i> ' . sprintf( $notify_text, $login_url, $register_url) . '</div>';
	 	return $html;
    }

    if (is_user_logged_in()){
        if (!current_user_can('campaign_form_submit')) {
            $html .= '<div class="helpmout-notification-login"><i class="fa fa-lock"></i>'.__("You do not have permission to start a project.","progression-elements-multifondo").'</div>';
            return $html;
        }
    }


    $html .= '<form type="post" action="" id="wpneofrontenddata">';


    //Title
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Title" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-title" value="'.$title.'">';
    $html .= '<small>'.__("Put the campaign title here","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Product Description
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Description" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    ob_start();
    wp_editor( $description, 'wpneo-form-description' );
    $html .= ob_get_clean();
    $html .= '<small>'.__("Put the campaign description here","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Product Short Description
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Short Description" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    ob_start();
    wp_editor( $short_description, 'wpneo-form-short-description', array('editor_height'=>200) );
    $html .= ob_get_clean();
    $html .= '<small>'.__("Put Here Product Short Description","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Category
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Category" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<select name="wpneo-form-category">';
    $all_cat = get_terms('product_cat',array( 'hide_empty' => false ) );
    foreach ($all_cat as $value) {
        $selected = ($category == $value->name) ? 'selected':'';
        $html .= '<option '.$selected.' value="'.$value->slug.'">'.$value->name.'</option>';
    }
    $html .= '</select>';
    $html .= '<small>'.__("Select your campaign category","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Tag
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Tag" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-tag" placeholder="'.__( "Tag","progression-elements-multifondo" ).'" value="'.$tag.'">';
    $html .= '<small>'.__("Separate tags with commas eg: tag1,tag2","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Image
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Image" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-image-url" class="wpneo-upload wpneo-form-image-url" value="'.$image_url.'">';
    $html .= '<input type="hidden" name="wpneo-form-image-id" class="wpneo-form-image-id" value="'.$image_id.'">';
    $html .= '<input type="button" id="cc-image-upload-file-button" class="wpneo-image-upload float-right" value="'.__("Upload Image","progression-elements-multifondo").'" data-url="'. get_site_url().'" />';
    $html .= '<small>'.__("Upload a campaign feature image","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Video
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Video" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-video" value="'.$video.'" placeholder="'.__( "https://","progression-elements-multifondo" ).'" >';
    $html .= '<small>'.__("Put the campaign video URL here","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Start Date
    $html .= '<div class="wpneo-single wpneo-first-half">';
    $html .= '<div class="wpneo-name">'.__( "Start Date" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-start-date" value="'.$start_date.'" id="wpneo_form_start_date">';
    $html .= '<small>'.__("Campaign start date (dd-mm-yy)","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //End Date
    $html .= '<div class="wpneo-single wpneo-second-half">';
    $html .= '<div class="wpneo-name">'.__( "End Date" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-end-date" value="'.$end_date.'" id="wpneo_form_end_date">';
    $html .= '<small>'.__("Campaign end date (dd-mm-yy)","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Minimum Amount
    if (get_option('wpneo_show_min_price') == 'true') {
        $html .= '<div class="wpneo-single wpneo-first-half">';
        $html .= '<div class="wpneo-name">'.__( "Minimum Amount" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="number" name="wpneo-form-min-price" value="'.$minimum_price.'">';
        $html .= '<small>'.__("Minimum campaign funding amount","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';
    }


    //Maximum Amount
    if (get_option('wpneo_show_max_price') == 'true') {
        $html .= '<div class="wpneo-single wpneo-second-half">';
        $html .= '<div class="wpneo-name">'.__( "Maximum Amount" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="number" name="wpneo-form-max-price" value="'.$maximum_price.'" >';
        $html .= '<small>'.__("Maximum campaign funding amount","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';
    }


    //Recomended Amount
    if (get_option('wpneo_show_recommended_price') == 'true') {
        $html .= '<div class="wpneo-single">';
        $html .= '<div class="wpneo-name">'.__( "Recomended Amount" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="number" name="wpneo-form-recommended-price" value="'.$recomended_price.'">';
        $html .= '<small>'.__("Recomended campaign funding amount","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';
    }


    //Funding Goal
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Funding Goal" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="number" name="wpneo-form-funding-goal" value="'.$funding_goal.'">';
    $html .= '<small>'.__("Campaign funding goal","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Campaign End Method
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "End Method" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<select name="wpneo-form-type">';

    if (get_option('wpneo_show_target_goal') == 'true') {
        $selected = $campaign_end_method == 'target_goal' ? 'selected="selected"' : '';
        $html .= '<option value="target_goal" '.$selected.'>' . __("Target Goal", "progression-elements-multifondo") . '</option>';
    }

    if (get_option('wpneo_show_target_date') == 'true') {
        $selected = $campaign_end_method == 'target_date' ? 'selected="selected"' : '';
        $html .= '<option value="target_date" '.$selected.'>' . __("Target Date", "progression-elements-multifondo") . '</option>';
    }

    if (get_option('wpneo_show_target_goal_and_date') == 'true') {
        $selected = $campaign_end_method == 'target_goal_and_date' ? 'selected="selected"' : '';
        $html .= '<option value="target_goal_and_date" '.$selected.'>' . __("Target Goal & Date", "progression-elements-multifondo") . '</option>';
    }

    if (get_option('wpneo_show_campaign_never_end') == 'true') {
        $selected = $campaign_end_method == 'never_end' ? 'selected="selected"' : '';
        $html .= '<option value="never_end" '.$selected.'>' . __("Campaign Never Ends", "progression-elements-multifondo") . '</option>';
    }

    $html .= '</select>';
    $html .= '<small>'.__("Choose the stage when campaign will end","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';



    //Show Contributor Table
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Contributor Table" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    if( $type == '1' )
        $checked = 'checked="checked"';
    $html .= '<input type="checkbox" '.$checked.' name="wpneo-form-contributor-table" value="1" >'.__("Show contributor table on campaign single page","progression-elements-multifondo" );
    $html .= '</div>';
    $html .= '</div>';


    //Mark Contributors as Anonymous
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Contributor Anonymity" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    if( $contributor_show == '1' )
        $checked2 = 'checked="checked"';
    $html .= '<input type="checkbox" '.$checked2.' name="wpneo-form-contributor-show" value="1" >'.__("Make contributors anonymous on the contributor table","progression-elements-multifondo" );
    $html .= '</div>';
    $html .= '</div>';

    //Country
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Country" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $countries_obj   = new WC_Countries();
    $countries   = $countries_obj->__get('countries');
    array_unshift($countries, 'Select a country');
    $html .= '<select name="wpneo-form-country">';
    foreach ($countries as $key=>$value) {
        if( $country==$key ){
            $html .= '<option selected="selected" value="'.$key.'">'.$value.'</option>';
        }else{
            $html .= '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $html .= '</select>';
    $html .= '<small>'.__("Select your country","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';


    //Location
    $html .= '<div class="wpneo-single">';
    $html .= '<div class="wpneo-name">'.__( "Location" , "progression-elements-multifondo" ).'</div>';
    $html .= '<div class="wpneo-fields">';
    $html .= '<input type="text" name="wpneo-form-location" value="'.$location.'" >';
    $html .= '<small>'.__("Put the campaign location here","progression-elements-multifondo").'</small>';
    $html .= '</div>';
    $html .= '</div>';

    /* ************************************ */
    /* *********** Clone Field ************ */
    /* ************************************ */


    $reward = stripslashes($reward);
    $reward_data_array = json_decode($reward, true);
    $meta_count = count($reward_data_array);
    $html .= '<div class="wpneo-reward-option">'.__("Reward Option","progression-elements-multifondo").'</div>';
    $html .= '<div class="panel" id="reward_options">';

    $month_list = array(
        '1' => __( 'January' , 'progression-elements-multifondo' ),
        '2' => __( 'February' , 'progression-elements-multifondo' ),
        '3' => __( 'March' , 'progression-elements-multifondo' ),
        '4' => __( 'April' , 'progression-elements-multifondo' ),
        '5' => __( 'May' , 'progression-elements-multifondo' ),
        '6' => __( 'June' , 'progression-elements-multifondo' ),
        '7' => __( 'July' , 'progression-elements-multifondo' ),
        '8' => __( 'August' , 'progression-elements-multifondo' ),
        '9' => __( 'September' , 'progression-elements-multifondo' ),
        '10' => __( 'October' , 'progression-elements-multifondo' ),
        '11' => __( 'November' , 'progression-elements-multifondo' ),
        '12' => __( 'December' , 'progression-elements-multifondo' ),
    );
    if ($meta_count > 0) {
        if (is_array($reward_data_array) && !empty($reward_data_array)) {
            foreach ($reward_data_array as $k => $v) {
                $html .=  "<div class='reward_group'>";
                $html .=  "<div class='campaign_rewards_field_copy'>";

                // Pledge Amount
                $html .= '<div class="wpneo-single">';
                $html .= '<div class="wpneo-name">'.__( "Pledge Amount" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $html .= '<input type="text" value="'.$v['wpneo_rewards_pladge_amount'].'" id="wpneo_rewards_pladge_amount[]" name="wpneo_rewards_pladge_amount[]" style="" class="wc_input_price">';
                $html .= '<small>'.__("Put the pledge amount here","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';


                // Reward Image
                $html .= '<div class="wpneo-single">';
                $html .= '<div class="wpneo-name">'.__( "Reward Image" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $attachment_url = '';
                if( $v['wpneo_rewards_image_field'] ){
                    $attachment_url = wp_get_attachment_url( $v['wpneo_rewards_image_field'] );
                }
                $html .= '<input type="text" name="wpneo_rewards_image_fields" class="wpneo-upload wpneo_rewards_image_field_url" value="'.$attachment_url.'">';
                $html .= '<input type="hidden" name="wpneo_rewards_image_field[]" class="wpneo_rewards_image_field" value="'.$v['wpneo_rewards_image_field'].'">';
                $html .= '<input type="button" id="cc-image-upload-file-button" class="wpneo-image-upload-btn float-right" value="'.__("Upload Image","progression-elements-multifondo").'"/>';
                $html .= '<small>'.__("Upload a reward image","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';


                // Reward
                $html .= '<div class="wpneo-single form-field wpneo_rewards_description[]_field">';
                $html .= '<div class="wpneo-name">'.__( "Reward" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $html .= '<textarea cols="20" rows="2" id="wpneo_rewards_description[]" name="wpneo_rewards_description[]" style="" class="short">'.$v['wpneo_rewards_description'].'</textarea>';
                $html .= '<small>'.__("Put the reward description here","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';


                // Estimated Delivery Month
                $html .= '<div class="wpneo-single wpneo-first-half">';
                $html .= '<div class="wpneo-name">'.__( "Estimated Delivery Month" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $html .= '<select style="" class="select short" name="wpneo_rewards_endmonth[]" id="wpneo_rewards_endmonth[]">';
                $html .= '<option value="">- Select -</option>';
                foreach($month_list as $key => $val){
                    $month_key = strtolower(substr($val,0,3));
                    $selected = ($v['wpneo_rewards_endmonth'] == $month_key)? 'selected':'';
                    $html .= '<option value="'.$month_key.'" '.$selected.'>'.$val.'</option>';
                }
                $html .= '</select>';
                $html .= '<small>'.__("Estimated Delivery Month of the Reward","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';


                // Estimated Delivery Year
                $html .= '<div class="wpneo-single wpneo-second-half">';
                $html .= '<div class="wpneo-name">'.__( "Estimated Delivery Year" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $html .= '<select style="" class="select short" name="wpneo_rewards_endyear[]" id="wpneo_rewards_endyear[]">';
                $html .= '<option value="">- Select -</option>';
                for ($i=2016; $i<=2021; $i++){
                    $selected = ($v['wpneo_rewards_endyear'] == $i)? 'selected':'';
                    $html .= '<option value="'.$i.'" '.$selected.'>'.$i.'</option>';
                }
                $html .= '</select>';
                $html .= '<small>'.__("Estimated Delivery Year of the Reward","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';


                // Quantity
                $html .= '<div class="wpneo-single">';
                $html .= '<div class="wpneo-name">'.__( "Quantity" , "progression-elements-multifondo" ).'</div>';
                $html .= '<div class="wpneo-fields">';
                $html .= '<input type="text" value="'.$v['wpneo_rewards_item_limit'].'" id="wpneo_rewards_item_limit[]" name="wpneo_rewards_item_limit[]" style="" class="wc_input_price">';
                $html .= '<small>'.__("Quantity of physical products","progression-elements-multifondo").'</small>';
                $html .= '</div>';
                $html .= '</div>';

                $html .= '<div class="wpneo-remove-button">';
                $html .= '<input name="remove_rewards" type="button" class="button tagadd removeCampaignRewards text-right" value="' . __('- Remove', 'progression-elements-multifondo') . '" />';
                $html .= '</div>';

                $html .=  "</div>";
                $html .=  "</div>";
            }
        }
    } else {
        $html .= '<div class="reward_group" style="display: block;">';
        $html .= '<div class="campaign_rewards_field_copy">';




        // Pledge Amount
        $html .= '<div class="wpneo-single">';
        $html .= '<div class="wpneo-name">'.__( "Pledge Amount" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="text" value="" id="wpneo_rewards_pladge_amount[]" name="wpneo_rewards_pladge_amount[]" style="" class="wc_input_price">';
        $html .= '<small>'.__("Pledge Amount","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';

        // Reward Image
        $html .= '<div class="wpneo-single">';
        $html .= '<div class="wpneo-name">'.__( "Reward Image" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="text" name="wpneo_rewards_image_fields" class="wpneo-upload wpneo_rewards_image_field_url" value="">';
        $html .= '<input type="hidden" name="wpneo_rewards_image_field[]" class="wpneo_rewards_image_field" value="">';
        $html .= '<input type="button" id="cc-image-upload-file-button" class="wpneo-image-upload-btn float-right" value="'.__("Upload Image","progression-elements-multifondo").'"/>';
        $html .= '<small>'.__("Upload a reward image","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';

        // Reward
        $html .= '<div class="wpneo-single form-field">';
        $html .= '<div class="wpneo-name">'.__( "Reward" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields float-right">';
        $html .= '<textarea cols="20" rows="2" id="wpneo_rewards_description[]" name="wpneo_rewards_description[]" style="" class="short"></textarea>';
        $html .= '<small>'.__("Reward Description","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';


        // Estimated Delivery Month
        $html .= '<div class="wpneo-single wpneo-first-half">';
        $html .= '<div class="wpneo-name">'.__( "Estimated Delivery Month" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<select style="" class="select short" name="wpneo_rewards_endmonth[]" id="wpneo_rewards_endmonth[]">';
        $html .= '<option selected="selected" value="">- Select -</option>';
        foreach( $month_list as $key => $val){
            $html .= '<option value="'.strtolower(substr($val,0,3)).'">'.$val.'</option>';
        }
        $html .= '</select>';
        $html .= '<small>'.__("Estimated Delivery Month of the Reward","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';

        // Estimated Delivery Year
        $html .= '<div class="wpneo-single wpneo-second-half">';
        $html .= '<div class="wpneo-name">'.__( "Estimated Delivery Year" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<select style="" class="select short" name="wpneo_rewards_endyear[]" id="wpneo_rewards_endyear[]">';
        $html .= '<option selected="selected" value="">- Select -</option>';
        $html .= '<option value="2016">2016</option>';
        $html .= '<option value="2017">2017</option>';
        $html .= '<option value="2018">2018</option>';
        $html .= '<option value="2019">2019</option>';
        $html .= '<option value="2020">2020</option>';
        $html .= '<option value="2021">2021</option>';
        $html .= '</select>';
        $html .= '<small>'.__("Estimated Delivery Year of the Reward","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';

        // Quantity
        $html .= '<div class="wpneo-single">';
        $html .= '<div class="wpneo-name">'.__( "Quantity" , "progression-elements-multifondo" ).'</div>';
        $html .= '<div class="wpneo-fields">';
        $html .= '<input type="text" value="" id="wpneo_rewards_item_limit[]" name="wpneo_rewards_item_limit[]" style="" class="wc_input_price">';
        $html .= '<small>'.__("Quantity of physical products","progression-elements-multifondo").'</small>';
        $html .= '</div>';
        $html .= '</div>';


        $html .= '<div class="wpneo-remove-button">';
        $html .= '<input type="button" value="'.__("- Remove","progression-elements-multifondo").'" class="button tagadd removeCampaignRewards" name="remove_rewards" style="display: none;">';
        $html .= '</div>';

        $html .= '</div>';

        $html .= '</div>';
    }

    if (WPNEO_CROWDFUNDING_TYPE == 'free') {
        
    }else {

        $html .= '<div id="rewards_addon_fields"></div>';
        $html .= '<div class="text-right">';
        $html .= '<input type="button" value="' . __("+ Add", "progression-elements-multifondo") . '" id="addreward" class="button tagadd" name="save">';
        $html .= '</div>';
    }

    $html .= '</div>';
    /* ************************************ */
    /* *********** Clone Field ************ */
    /* ************************************ */

    $html .= $edit_form;
    $html .= $edit_id;

    $html .= apply_filters('wpneo_before_closing_crowdfunding_campaign_form', '' );

    $requirement_title = get_option( 'wpneo_requirement_title', '' );
    $requirement_text = get_option( 'wpneo_requirement_text', '' );
    $requirement_agree_title = get_option( 'wpneo_requirement_agree_title', '' );
    $html .= '<div class="wpneo-title">'.$requirement_title.'</div>';
    $html .= '<div class="wpneo-text">'.$requirement_text.'</div>';
    $html .= '<div class="wpneo-requirement-title"><input type="checkbox" value="agree" name="wpneo_terms_agree"> '.$requirement_agree_title.'</div>';



    $var = get_option( 'wpneo_crowdfunding_dashboard_page_id', '' );
    if( $var != '' ){
        $var = get_permalink( $var );
    }else{
        $var = get_home_url();
    }
    $html .= '<div class="wpneo-form-action">';
    $html .= '<input type="hidden" name="action" value="addfrontenddata"/>';
    $html .= '<input type="submit" class="wpneo-submit-campaign" value="'.__("Submit campaign","progression-elements-multifondo").'">';
    $html .= '<a href="'.$var.'" class="wpneo-cancel-campaign">'.__("Cancel","progression-elements-multifondo").'</a>';
    $html .= '</div>';

    $html .= '</form>';

    return $html;
}

}