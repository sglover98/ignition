<?php


add_action('init', 'helpmtout_remove_parent_theme_shortcodes');

function helpmtout_remove_parent_theme_shortcodes() {
	remove_shortcode('wpneo_crowdfunding_form','wpneo_shortcode_croudfunding_form');
	add_shortcode( 'wpneo_crowdfunding_form', 'wpneo_crowdfunding_form' );	
}




if (! function_exists('wpneo_crowdfunding_wc_toggle_login_form')) {
	function wpneo_crowdfunding_wc_toggle_login_form(){
		$notify_text 	= wp_kses( __('Please <a href="%s">login</a> or <a href="%s">register for a new account</a> in order to view your dashboard.', 'progression-elements-multifondo' ) , TRUE);
		$login_url 		= get_permalink( wc_get_page_id( 'myaccount' ) );
		$register_url 	= get_permalink( wc_get_page_id( 'myaccount' ) ); //get_page_link (get_option('wpneo_registration_page_id','') );
	
		$html = '<div class="helpmout-notification-login"><i class="fa fa-lock"></i> ' . sprintf( $notify_text, $login_url, $register_url) . '</div>';
		return $html;
	}
}

