jQuery(document).ready( function(){
    jQuery('.demos_import').css("display","block");
	jQuery('.impor_msg').css("display","none");
	jQuery('.loding_img').css("display","none");
	
});
